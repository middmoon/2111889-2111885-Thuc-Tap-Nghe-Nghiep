import React from "react";
import withLayout from "../layout/withLayout";
const PostDetail = () => {
  return <div>PostDetail</div>;
};

export default withLayout(PostDetail);
